using System;
using System.Collections.Generic;

namespace Group_work_OOP
{
    // Quiz class with questions and category
    public class Quiz
    {
        private static int _nextQuizIdentifier = 1;
        private int _quizIdentifier;
        private string _quizTitle;
        private string _quizDescription;
        private Category _quizCategory;
        private List<Question> _quizQuestions;
        private DateTime _quizDate;

        // Read only identifier
        public int QuizID { get { return _quizIdentifier; } }
        public string QuizTitle { get { return _quizTitle; } set { _quizTitle = value; } }
        public string QuizDescription { get { return _quizDescription; } set { _quizDescription = value; } }
        public Category QuizCategory { get { return _quizCategory; } set { _quizCategory = value; } }
        public List<Question> QuizQuestions { get { return _quizQuestions; } set { _quizQuestions = value; } }
        public DateTime QuizDate { get { return _quizDate; } set { _quizDate = value; } }

        // Defaults
        public Quiz()
        {
            _quizIdentifier = _nextQuizIdentifier++;
            _quizTitle = string.Empty;
            _quizDescription = string.Empty;
            _quizCategory = null;
            _quizQuestions = new List<Question>();
            _quizDate = DateTime.Now;
        }

        // Create quiz with values
        public Quiz(string title, string description, Category category, List<Question> questions, DateTime date)
        {
            _quizIdentifier = _nextQuizIdentifier++;
            _quizTitle = title;
            _quizDescription = description;
            _quizCategory = category;
            _quizQuestions = new List<Question>(questions);
            _quizDate = date;
        }
    }
}
