using System;

namespace Group_work_OOP
{
    // Quiz category class
    public class Category
    {
        private static int _nextCategoryIdentifier = 1;
        private int _categoryIdentifier;
        private string _categoryName;
        private string _categoryDescription;

        // Read only category identifier
        public int CategoryID { get { return _categoryIdentifier; } }
        public string CategoryName { get { return _categoryName; } set { _categoryName = value; } }
        public string CategoryDescription { get { return _categoryDescription; } set { _categoryDescription = value; } }

        // Default values
        public Category()
        {
            _categoryIdentifier = _nextCategoryIdentifier++;
            _categoryName = string.Empty;
            _categoryDescription = string.Empty;
        }

        // Create category with values
        public Category(string name, string description)
        {
            _categoryIdentifier = _nextCategoryIdentifier++;
            _categoryName = name;
            _categoryDescription = description;
        }
    }
}
