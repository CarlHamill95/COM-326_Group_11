using System;

namespace Group_work_OOP
{
    // Basic user class
    public class User
    {
        private static int _nextIdentifier = 1;

        private int _identifier;
        private string _userName;
        private string _passwordValue;
        private string _emailAddress;
        private string _roleName;

        // Read only identifier
        public int Id { get { return _identifier; } }
        public string Username { get { return _userName; } set { _userName = value; } }
        public string Password { get { return _passwordValue; } set { _passwordValue = value; } }
        public string Email { get { return _emailAddress; } set { _emailAddress = value; } }
        public string Role { get { return _roleName; } set { _roleName = value; } }

        // Default constructor sets simple defaults
        public User()
        {
            _identifier = _nextIdentifier++;
            _userName = string.Empty;
            _passwordValue = string.Empty;
            _emailAddress = string.Empty;
            _roleName = "User";
        }

        // Create a user with provided values
        public User(string userName, string password, string email, string role)
        {
            _identifier = _nextIdentifier++;
            _userName = userName;
            _passwordValue = password;
            _emailAddress = email;
            _roleName = role;
        }
    }
}
