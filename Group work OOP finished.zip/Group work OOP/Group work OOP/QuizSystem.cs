using System;
using System.Collections.Generic;
using System.IO;

namespace Group_work_OOP
{
    // Central store and helpers for the quiz system
    public static class QuizSystem
    {
        public static List<User> Users = new List<User>();
        public static List<Category> Categories = new List<Category>();
        public static List<Question> Questions = new List<Question>();
        public static List<Quiz> Quizzes = new List<Quiz>();

        private const string StudentsCsv = "students.csv";
        private const string ResultsCsv = "results.csv";

        // Simple record for storing best score per user per category
        public class ResultRecord
        {
            public string Username { get; set; }
            public int CategoryID { get; set; }
            public int Score { get; set; }
        }

        // Stored best results
        public static List<ResultRecord> Results = new List<ResultRecord>();

        // Add some sample data so the program has something to use
        static QuizSystem()
        {
            // Load persisted students first (if any)
            try
            {
                LoadStudentsFromCsv(StudentsCsv);
            }
            catch
            {
                // ignore load failures; continue with defaults
            }

            // Load persisted results
            try
            {
                LoadResultsFromCsv(ResultsCsv);
            }
            catch
            {
                // ignore
            }

            var administratorUser = new Admin("admin", "adminpass", "admin@example.com", DateTime.Now);
            Users.Add(administratorUser);

            var studentUser = new Student("john", "1234", "john@example.com", "active", null);
            // Only add if not already loaded from CSV
            if (!Users.Exists(u => u.Username == studentUser.Username && u.Role == "Student"))
            {
                Users.Add(studentUser);
            }

            // Also import any pre-made accounts from UserAccounts so the two login paths agree
            foreach (var a in UserAccounts.adminList)
            {
                // Avoid duplicates by checking existing usernames
                bool exists = Users.Exists(u => u.Username == a.AdminName && u.Role == "Admin");
                if (!exists)
                {
                    Users.Add(new Admin(a.AdminName, a.AdminPass, a.AdminName + "@example.com", DateTime.MinValue));
                }
            }

            foreach (var s in UserAccounts.studentList)
            {
                bool exists = Users.Exists(u => u.Username == s.StudentName && u.Role == "Student");
                if (!exists)
                {
                    Users.Add(new Student(s.StudentName, s.StudentPassword, s.StudentName + "@example.com", "active", null));
                }
            }

            // Preload categories as specified
            var categoryNamesAndDescriptions = new List<Tuple<string, string>>
            {
                Tuple.Create("Programming", "Concepts of object-oriented programming and coding principles"),
                Tuple.Create("Data Structures", "Arrays, lists, stacks, queues, trees, and their applications"),
                Tuple.Create("Software Design", "Design patterns, architecture principles, and system modelling"),
                Tuple.Create("Web Development", "HTML, CSS, JavaScript, and client-server interactions"),
                Tuple.Create("Database Systems", "SQL queries, relational models, normalization, and transactions"),
                Tuple.Create("Cybersecurity Basics", "Encryption, authentication, and common security threats"),
                Tuple.Create("Computer Networks", "Protocols, IP addressing, routing, and network layers")
            };

            foreach (var cd in categoryNamesAndDescriptions)
            {
                // avoid duplicates by name
                bool exists = Categories.Exists(c => c.CategoryName == cd.Item1);
                if (!exists)
                {
                    Categories.Add(new Category(cd.Item1, cd.Item2));
                }
            }

            // Use the existing "Programming" category for the OOP quiz so students selecting Programming see the quiz
            Category programmingCategory = Categories.Find(c => c.CategoryName == "Programming");
            if (programmingCategory == null)
            {
                programmingCategory = new Category("Programming", "Concepts of object-oriented programming and coding principles");
                Categories.Add(programmingCategory);
            }

            // Preload the 10 required OOP questions (do not modify the text, options or difficulty)
            var q1 = new Question(
                "What does OOP stand for?",
                new List<string> { "Object-Oriented Programming", "Operational Output Processing", "Open Order Protocol", "Overloaded Operator Procedure" },
                "Object-Oriented Programming",
                "Easy");

            var q2 = new Question(
                "Which of the following is NOT a core principle of OOP?",
                new List<string> { "Encapsulation", "Polymorphism", "Abstraction", "Compilation" },
                "Compilation",
                "Easy");

            var q3 = new Question(
                "What is encapsulation in object-oriented programming?",
                new List<string> { "Binding data and methods", "Inheritance", "Overloading", "Creating objects" },
                "Binding data and methods",
                "Medium");

            var q4 = new Question(
                "Which keyword is used in C# to inherit a class?",
                new List<string> { "extends", "inherits", ":", "base" },
                ":",
                "Medium");

            var q5 = new Question(
                "What is the purpose of a constructor in a class?",
                new List<string> { "To destroy objects", "To initialize objects", "To inherit methods", "To override properties" },
                "To initialize objects",
                "Easy");

            var q6 = new Question(
                "Which concept allows multiple methods with the same name but different parameters?",
                new List<string> { "Inheritance", "Polymorphism", "Overloading", "Encapsulation" },
                "Overloading",
                "Medium");

            var q7 = new Question(
                "What is the base class for all classes in C#?",
                new List<string> { "System.Object", "BaseClass", "RootClass", "MainClass" },
                "System.Object",
                "Hard");

            var q8 = new Question(
                "What is the difference between a class and an object?",
                new List<string> { "Class is an instance, object is a blueprint", "Class is a blueprint, object is an instance", "They are the same", "Object inherits class" },
                "Class is a blueprint, object is an instance",
                "Medium");

            var q9 = new Question(
                "Which access modifier makes a member accessible only within its own class?",
                new List<string> { "public", "private", "protected", "internal" },
                "private",
                "Easy");

            var q10 = new Question(
                "What is polymorphism in OOP?",
                new List<string> { "Ability to hide data", "Ability to inherit methods", "Ability to take many forms", "Ability to override constructors" },
                "Ability to take many forms",
                "Medium");

            // Add to global questions list
            Questions.AddRange(new List<Question> { q1, q2, q3, q4, q5, q6, q7, q8, q9, q10 });

            // Create and add the sample OOP quiz using these exact questions and link it to Programming category
            var sampleQuiz = new Quiz("OOP Quiz", "Basic OOP questions", programmingCategory, new List<Question> { q1, q2, q3, q4, q5, q6, q7, q8, q9, q10 }, DateTime.Now);
            Quizzes.Add(sampleQuiz);
        }

        // Load students from CSV file. CSV format: Username,Password,Email,Role
        public static void LoadStudentsFromCsv(string path)
        {
            if (!File.Exists(path)) return;
            using (var reader = new StreamReader(path))
            {
                string header = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var parts = line.Split(',');
                    if (parts.Length < 4) continue;
                    var username = parts[0].Trim().Trim('"');
                    var password = parts[1].Trim().Trim('"');
                    var email = parts[2].Trim().Trim('"');
                    var role = parts[3].Trim().Trim('"');
                    if (role.Equals("Student", StringComparison.OrdinalIgnoreCase))
                    {
                        // avoid duplicates
                        if (!Users.Exists(u => u.Username == username && u.Role == "Student"))
                        {
                            Users.Add(new Student(username, password, email, "active", null));
                        }
                    }
                }
            }
        }

        // Save student accounts to CSV
        public static void SaveStudentsToCsv(string path)
        {
            try
            {
                using (var writer = new StreamWriter(path, false))
                {
                    writer.WriteLine("Username,Password,Email,Role");
                    for (int i = 0; i < Users.Count; i++)
                    {
                        var u = Users[i];
                        if (u.Role == "Student")
                        {
                            // Escape commas in fields if present by wrapping with quotes
                            string username = u.Username.Contains(",") ? $"\"{u.Username}\"" : u.Username;
                            string password = u.Password.Contains(",") ? $"\"{u.Password}\"" : u.Password;
                            string email = u.Email.Contains(",") ? $"\"{u.Email}\"" : u.Email;
                            writer.WriteLine($"{username},{password},{email},Student");
                        }
                    }
                }
            }
            catch
            {
                // ignore save errors for now
            }
        }

        // Load results from CSV file. CSV format: Username,CategoryID,Score
        public static void LoadResultsFromCsv(string path)
        {
            Results.Clear();
            if (!File.Exists(path)) return;
            using (var reader = new StreamReader(path))
            {
                string header = reader.ReadLine();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var parts = line.Split(',');
                    if (parts.Length < 3) continue;
                    var username = parts[0].Trim().Trim('"');
                    int categoryId = 0;
                    int score = 0;
                    int.TryParse(parts[1].Trim(), out categoryId);
                    int.TryParse(parts[2].Trim(), out score);
                    if (!string.IsNullOrEmpty(username))
                    {
                        Results.Add(new ResultRecord { Username = username, CategoryID = categoryId, Score = score });
                    }
                }
            }
        }

        // Save results to CSV
        public static void SaveResultsToCsv(string path)
        {
            try
            {
                using (var writer = new StreamWriter(path, false))
                {
                    writer.WriteLine("Username,CategoryID,Score");
                    for (int i = 0; i < Results.Count; i++)
                    {
                        var r = Results[i];
                        string username = r.Username.Contains(",") ? $"\"{r.Username}\"" : r.Username;
                        writer.WriteLine($"{username},{r.CategoryID},{r.Score}");
                    }
                }
            }
            catch
            {
                // ignore
            }
        }

        // Record a student's result for a category; only keep best score
        public static void RecordStudentResult(string username, int categoryId, int score)
        {
            if (string.IsNullOrEmpty(username)) return;
            // find existing
            var existing = Results.Find(r => r.Username == username && r.CategoryID == categoryId);
            if (existing == null)
            {
                Results.Add(new ResultRecord { Username = username, CategoryID = categoryId, Score = score });
            }
            else
            {
                if (score > existing.Score)
                {
                    existing.Score = score;
                }
            }
            SaveResultsToCsv(ResultsCsv);
        }

        // Return student's results as tuples of category and best score
        public static List<Tuple<Category, int>> GetStudentResults(string username)
        {
            var list = new List<Tuple<Category, int>>();
            if (string.IsNullOrEmpty(username)) return list;
            foreach (var r in Results)
            {
                if (r.Username == username)
                {
                    var cat = Categories.Find(c => c.CategoryID == r.CategoryID);
                    if (cat != null)
                    {
                        list.Add(Tuple.Create(cat, r.Score));
                    }
                }
            }
            return list;
        }

        // Return maximum possible points for the first quiz in the category (sum of difficulty points)
        public static int GetMaxPointsForCategory(int categoryId)
        {
            for (int i = 0; i < Quizzes.Count; i++)
            {
                var q = Quizzes[i];
                if (q.QuizCategory != null && q.QuizCategory.CategoryID == categoryId)
                {
                    int max = 0;
                    for (int j = 0; j < q.QuizQuestions.Count; j++)
                    {
                        max += DifficultyToPoints(q.QuizQuestions[j].QuestionDifficultyLevel);
                    }
                    return max;
                }
            }
            return 0;
        }

        // Return the administrator username when credentials match otherwise return null
        public static string AuthenticateAdmin(string username, string password)
        {
            for (int index = 0; index < Users.Count; index++)
            {
                var currentUser = Users[index];
                if (currentUser.Role == "Admin")
                {
                    if (currentUser.Username == username && currentUser.Password == password)
                    {
                        return currentUser.Username;
                    }
                }
            }
            return null;
        }

        // Return the student username when credentials match otherwise return null
        public static string AuthenticateStudent(string username, string password)
        {
            for (int index = 0; index < Users.Count; index++)
            {
                var currentUser = Users[index];
                if (currentUser.Role == "Student")
                {
                    if (currentUser.Username == username && currentUser.Password == password)
                    {
                        return currentUser.Username;
                    }
                }
            }
            return null;
        }

        // Create and add a new student account
        public static void AddStudent(string username, string password, string email)
        {
            var student = new Student(username, password, email, "active", null);
            Users.Add(student);
            // persist
            SaveStudentsToCsv(StudentsCsv);
        }

        // Remove a student account by username
        public static bool RemoveStudentByUsername(string username)
        {
            for (int i = 0; i < Users.Count; i++)
            {
                var u = Users[i];
                if (u.Role == "Student" && u.Username == username)
                {
                    Users.RemoveAt(i);
                    // persist
                    SaveStudentsToCsv(StudentsCsv);
                    return true;
                }
            }
            return false;
        }

        // Return a list of quizzes that belong to the given category id
        public static List<Quiz> GetQuizzesByCategoryId(int categoryId)
        {
            var matchingQuizzes = new List<Quiz>();
            for (int index = 0; index < Quizzes.Count; index++)
            {
                var currentQuiz = Quizzes[index];
                if (currentQuiz.QuizCategory != null && currentQuiz.QuizCategory.CategoryID == categoryId)
                {
                    matchingQuizzes.Add(currentQuiz);
                }
            }
            return matchingQuizzes;
        }

        // Save questions to a csv file in a simple format
        public static void SaveQuestionsToCsv(string path)
        {
            using (var streamWriter = new StreamWriter(path))
            {
                streamWriter.WriteLine("QuestionID,QuestionText,Options,CorrectAnswer,Difficulty");
                for (int questionIndex = 0; questionIndex < Questions.Count; questionIndex++)
                {
                    var question = Questions[questionIndex];
                    // build the options field with a pipe character between options
                    string optionsText = "";
                    for (int optionIndex = 0; optionIndex < question.QuestionOptions.Count; optionIndex++)
                    {
                        optionsText += question.QuestionOptions[optionIndex];
                        if (optionIndex < question.QuestionOptions.Count - 1)
                        {
                            optionsText += "|";
                        }
                    }
                    // write one line per question
                    streamWriter.WriteLine(question.QuestionID + ",\"" + question.QuestionText + "\",\"" + optionsText + "\",\"" + question.QuestionCorrectAnswer + "\"," + question.QuestionDifficultyLevel);
                }
            }
        }

        // Map difficulty level to points for internal use
        private static int DifficultyToPoints(string difficulty)
        {
            if (difficulty == null) return 0;
            difficulty = difficulty.Trim().ToLower();
            if (difficulty == "easy") return 1;
            if (difficulty == "medium") return 2;
            if (difficulty == "hard") return 3;
            return 0;
        }
    }
}
