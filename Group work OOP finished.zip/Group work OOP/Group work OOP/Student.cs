using System;

namespace Group_work_OOP
{
    // Student user with status
    public class Student : User
    {
        private string _statusValue; // active or inactive
        private object _assignedCategory;

        public string Status { get { return _statusValue; } private set { _statusValue = value; } }
        public object Category { get { return _assignedCategory; } set { _assignedCategory = value; } }

        // Default student
        public Student() : base()
        {
            Role = "Student";
            _statusValue = "active";
            _assignedCategory = null;
        }

        // Create student with values
        public Student(string userName, string password, string email, string status, object category)
            : base(userName, password, email, "Student")
        {
            _statusValue = status;
            _assignedCategory = category;
        }

        // Change status requires an administrator user
        public void SetStatus(string status, Admin byAdministrator)
        {
            if (byAdministrator == null) throw new ArgumentNullException(nameof(byAdministrator));
            _statusValue = status;
        }
    }
}
