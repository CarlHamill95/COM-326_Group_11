using System;
using System.Collections.Generic;

namespace Group_work_OOP
{
    // Single question with options and answer
    public class Question
    {
        private static int _nextQuestionIdentifier = 1;
        private int _questionIdentifier;
        private string _questionText;
        private List<string> _questionOptions;
        private string _questionCorrectAnswer;
        private string _questionDifficultyLevel;

        // Read only identifier
        public int QuestionID { get { return _questionIdentifier; } }
        public string QuestionText { get { return _questionText; } set { _questionText = value; } }
        public List<string> QuestionOptions { get { return _questionOptions; } set { _questionOptions = value; } }
        public string QuestionCorrectAnswer { get { return _questionCorrectAnswer; } set { _questionCorrectAnswer = value; } }
        public string QuestionDifficultyLevel { get { return _questionDifficultyLevel; } set { _questionDifficultyLevel = value; } }

        // Default values
        public Question()
        {
            _questionIdentifier = _nextQuestionIdentifier++;
            _questionText = string.Empty;
            _questionOptions = new List<string>();
            _questionCorrectAnswer = string.Empty;
            _questionDifficultyLevel = string.Empty;
        }

        // Create question with values
        public Question(string text, List<string> options, string correct, string difficulty)
        {
            _questionIdentifier = _nextQuestionIdentifier++;
            _questionText = text;
            _questionOptions = new List<string>(options);
            _questionCorrectAnswer = correct;
            _questionDifficultyLevel = difficulty;
        }
    }
}
