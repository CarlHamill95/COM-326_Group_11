using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Group_work_OOP
{
    public static class QuizSystem
    {
        public static List<User> Users { get; } = new List<User>();
        public static List<Category> Categories { get; } = new List<Category>();
        public static List<Question> Questions { get; } = new List<Question>();
        public static List<Quiz> Quizzes { get; } = new List<Quiz>();

        private const string StudentsCsv = "students.csv";
        private const string ResultsCsv = "results.csv";

        public class ResultRecord { public string Username { get; set; } public int CategoryID { get; set; } public int Score { get; set; } }
        private static List<ResultRecord> Results { get; } = new List<ResultRecord>();

        static QuizSystem()
        {
            // ensure accounts
            Users.AddRange(UserAccounts.adminList.Select(a => new Admin(a.AdminName, a.AdminPass, a.AdminName + "@example.com", DateTime.MinValue)));
            Users.AddRange(UserAccounts.studentList.Select(s => new Student(s.StudentName, s.StudentPassword, s.StudentName + "@example.com", "active", null)));
            if (!Users.Any(u => u.Role == "Admin")) Users.Add(new Admin("admin", "adminpass", "admin@example.com", DateTime.MinValue));
            if (!Users.Any(u => u.Role == "Student")) Users.Add(new Student("john", "1234", "john@example.com", "active", null));

            // categories
            if (!Categories.Any())
            {
                Categories.Add(new Category("Programming", "OOP and programming"));
                Categories.Add(new Category("Data Structures", "Data structures"));
                Categories.Add(new Category("Software Design", "Design"));
                Categories.Add(new Category("Web Development", "Web"));
                Categories.Add(new Category("Database Systems", "DB"));
                Categories.Add(new Category("Cybersecurity Basics", "Security"));
                Categories.Add(new Category("Computer Networks", "Networks"));
            }

            // Build quizzes and questions and attach to the category instances in Categories
            // Programming (OOP) questions
            var progCat = Categories.Find(c => c.CategoryName == "Programming");
            var progQuestions = new List<Question>
            {
                new Question("What does OOP stand for?", new List<string>{"Object-Oriented Programming","Operational Output Processing","Open Order Protocol","Overloaded Operator Procedure"}, "Object-Oriented Programming", "Easy"),
                new Question("Which of the following is NOT a core principle of OOP?", new List<string>{"Encapsulation","Polymorphism","Abstraction","Compilation"}, "Compilation", "Easy"),
                new Question("What is encapsulation in object-oriented programming?", new List<string>{"Binding data and methods","Inheritance","Overloading","Creating objects"}, "Binding data and methods", "Medium"),
                new Question("Which keyword is used in C# to inherit a class?", new List<string>{"extends","inherits",":","base"}, ":", "Medium"),
                new Question("What is the purpose of a constructor in a class?", new List<string>{"To destroy objects","To initialize objects","To inherit methods","To override properties"}, "To initialize objects", "Easy"),
                new Question("Which concept allows multiple methods with the same name but different parameters?", new List<string>{"Inheritance","Polymorphism","Overloading","Encapsulation"}, "Overloading", "Medium"),
                new Question("What is the base class for all classes in C#?", new List<string>{"System.Object","BaseClass","RootClass","MainClass"}, "System.Object", "Hard"),
                new Question("What is the difference between a class and an object?", new List<string>{"Class is an instance, object is a blueprint","Class is a blueprint, object is an instance","They are the same","Object inherits class"}, "Class is a blueprint, object is an instance", "Medium"),
                new Question("Which access modifier makes a member accessible only within its own class?", new List<string>{"public","private","protected","internal"}, "private", "Easy"),
                new Question("What is polymorphism in OOP?", new List<string>{"Ability to hide data","Ability to inherit methods","Ability to take many forms","Ability to override constructors"}, "Ability to take many forms", "Medium")
            };
            Questions.AddRange(progQuestions);
            if (progCat != null) Quizzes.Add(new Quiz("OOP Quiz", "Basic OOP questions", progCat, progQuestions, DateTime.MinValue));

            // Data Structures
            var dsCat = Categories.Find(c => c.CategoryName == "Data Structures");
            var dsQuestions = new List<Question>
            {
                new Question("What data structure follows the FIFO principle?", new List<string>{"Stack","Queue","Tree","Graph"}, "Queue", "Easy"),
                new Question("Which data structure uses LIFO ordering?", new List<string>{"Queue","Stack","Array","Linked List"}, "Stack", "Easy"),
                new Question("Which structure stores elements in contiguous memory locations?", new List<string>{"Array","Linked List","Stack","Queue"}, "Array", "Easy"),
                new Question("Which data structure allows dynamic memory allocation?", new List<string>{"Array","Linked List","Stack","Tree"}, "Linked List", "Medium"),
                new Question("Which traversal method visits the root node first?", new List<string>{"Inorder","Preorder","Postorder","Level-order"}, "Preorder", "Medium"),
                new Question("What is the average time complexity of searching in a balanced binary search tree?", new List<string>{"O(1)","O(log n)","O(n)","O(n^2)"}, "O(log n)", "Medium"),
                new Question("Which data structure is best for implementing recursion?", new List<string>{"Queue","Stack","Tree","Graph"}, "Stack", "Medium"),
                new Question("Which data structure is used internally by a hash table to handle collisions?", new List<string>{"Stack","Queue","Linked List","Tree"}, "Linked List", "Hard"),
                new Question("Which traversal uses a queue internally?", new List<string>{"Depth-first","Breadth-first","Inorder","Postorder"}, "Breadth-first", "Hard"),
                new Question("What is the worst-case time complexity of linear search?", new List<string>{"O(log n)","O(1)","O(n)","O(n^2)"}, "O(n)", "Hard")
            };
            Questions.AddRange(dsQuestions);
            if (dsCat != null) Quizzes.Add(new Quiz("Data Structures Quiz", "Data Structures questions", dsCat, dsQuestions, DateTime.MinValue));

            // Software Design
            var sdCat = Categories.Find(c => c.CategoryName == "Software Design");
            var sdQuestions = new List<Question>
            {
                new Question("What is a design pattern?", new List<string>{"Coding rule","Reusable solution","Algorithm","Framework"}, "Reusable solution", "Easy"),
                new Question("Which design principle promotes loose coupling?", new List<string>{"Inheritance","Encapsulation","Dependency Injection","Compilation"}, "Dependency Injection", "Easy"),
                new Question("Which pattern ensures only one instance of a class exists?", new List<string>{"Factory","Singleton","Observer","Adapter"}, "Singleton", "Easy"),
                new Question("Which UML diagram shows class relationships?", new List<string>{"Sequence","Use Case","Class","Activity"}, "Class", "Medium"),
                new Question("Which principle states a class should have only one reason to change?", new List<string>{"Open-Closed","Single Responsibility","Liskov","Interface Segregation"}, "Single Responsibility", "Medium"),
                new Question("Which pattern is used to create objects without specifying the exact class?", new List<string>{"Singleton","Factory","Adapter","Decorator"}, "Factory", "Medium"),
                new Question("Which SOLID principle focuses on substitutability?", new List<string>{"SRP","OCP","LSP","ISP"}, "LSP", "Medium"),
                new Question("Which pattern allows behaviour to be added dynamically?", new List<string>{"Adapter","Decorator","Factory","Proxy"}, "Decorator", "Hard"),
                new Question("Which diagram best shows object interactions over time?", new List<string>{"Class","Sequence","State","Component"}, "Sequence", "Hard"),
                new Question("Which architectural style separates data, UI, and logic?", new List<string>{"MVC","Monolithic","Client-server","Pipe-filter"}, "MVC", "Hard")
            };
            Questions.AddRange(sdQuestions);
            if (sdCat != null) Quizzes.Add(new Quiz("Software Design Quiz", "Software Design questions", sdCat, sdQuestions, DateTime.MinValue));

            // Web Development
            var wdCat = Categories.Find(c => c.CategoryName == "Web Development");
            var wdQuestions = new List<Question>
            {
                new Question("Which language structures web content?", new List<string>{"CSS","HTML","JavaScript","SQL"}, "HTML", "Easy"),
                new Question("Which language styles web pages?", new List<string>{"HTML","CSS","JavaScript","PHP"}, "CSS", "Easy"),
                new Question("Which language adds interactivity to web pages?", new List<string>{"HTML","CSS","JavaScript","XML"}, "JavaScript", "Easy"),
                new Question("What does HTTP stand for?", new List<string>{"HyperText Transfer Protocol","High Transfer Text Protocol","Host Transfer Tool","Hyper Tool Protocol"}, "HyperText Transfer Protocol", "Medium"),
                new Question("Which HTTP method retrieves data?", new List<string>{"POST","GET","PUT","DELETE"}, "GET", "Medium"),
                new Question("Which tag links an external CSS file?", new List<string>{"<script>","<style>","<link>","<meta>"}, "<link>", "Medium"),
                new Question("What does CSS stand for?", new List<string>{"Computer Style Sheets","Cascading Style Sheets","Creative Style System","Color Style Sheets"}, "Cascading Style Sheets", "Medium"),
                new Question("Which protocol secures HTTP traffic?", new List<string>{"FTP","SSL","HTTPS","TCP"}, "HTTPS", "Hard"),
                new Question("Which JavaScript feature allows asynchronous operations?", new List<string>{"Loops","Callbacks","Variables","Operators"}, "Callbacks", "Hard"),
                new Question("Which storage persists data after browser closure?", new List<string>{"SessionStorage","Cookies","LocalStorage","Cache"}, "LocalStorage", "Hard")
            };
            Questions.AddRange(wdQuestions);
            if (wdCat != null) Quizzes.Add(new Quiz("Web Development Quiz", "Web Development questions", wdCat, wdQuestions, DateTime.MinValue));

            // Database Systems
            var dbCat = Categories.Find(c => c.CategoryName == "Database Systems");
            var dbQuestions = new List<Question>
            {
                new Question("What does SQL stand for?", new List<string>{"Structured Query Language","Simple Query Language","Sequential Query Logic","Standard Query List"}, "Structured Query Language", "Easy"),
                new Question("Which command retrieves data from a table?", new List<string>{"INSERT","UPDATE","DELETE","SELECT"}, "SELECT", "Easy"),
                new Question("What is a primary key?", new List<string>{"Duplicate column","Unique identifier","Foreign reference","Index"}, "Unique identifier", "Easy"),
                new Question("Which SQL clause filters rows?", new List<string>{"GROUP BY","ORDER BY","WHERE","HAVING"}, "WHERE", "Medium"),
                new Question("Which normal form removes partial dependency?", new List<string>{"1NF","2NF","3NF","BCNF"}, "2NF", "Medium"),
                new Question("What type of relationship uses a junction table?", new List<string>{"One-to-one","One-to-many","Many-to-many","Recursive"}, "Many-to-many", "Medium"),
                new Question("Which constraint enforces referential integrity?", new List<string>{"PRIMARY KEY","FOREIGN KEY","UNIQUE","CHECK"}, "FOREIGN KEY", "Medium"),
                new Question("Which isolation level prevents dirty reads?", new List<string>{"Read Uncommitted","Read Committed","Repeatable Read","Serializable"}, "Read Committed", "Hard"),
                new Question("Which command removes a table completely?", new List<string>{"DELETE","DROP","REMOVE","CLEAR"}, "DROP", "Hard"),
                new Question("Which index improves search speed?", new List<string>{"Clustered","Temporary","Dynamic","Local"}, "Clustered", "Hard")
            };
            Questions.AddRange(dbQuestions);
            if (dbCat != null) Quizzes.Add(new Quiz("Database Systems Quiz", "Database Systems questions", dbCat, dbQuestions, DateTime.MinValue));

            // Cybersecurity
            var csCat = Categories.Find(c => c.CategoryName == "Cybersecurity Basics");
            var csQuestions = new List<Question>
            {
                new Question("What does encryption do?", new List<string>{"Deletes data","Protects data","Compresses data","Copies data"}, "Protects data", "Easy"),
                new Question("What is authentication?", new List<string>{"Data storage","Identity verification","Encryption","Backup"}, "Identity verification", "Easy"),
                new Question("Which is a strong password?", new List<string>{"123456","password","P@ssw0rd!","abc123"}, "P@ssw0rd!", "Easy"),
                new Question("What does MFA stand for?", new List<string>{"Multiple File Access","Multi-Factor Authentication","Managed Firewall Access","Modular Function Access"}, "Multi-Factor Authentication", "Medium"),
                new Question("Which attack floods a system with traffic?", new List<string>{"Phishing","Malware","DDoS","Spyware"}, "DDoS", "Medium"),
                new Question("Which malware disguises itself as legitimate software?", new List<string>{"Worm","Trojan","Virus","Ransomware"}, "Trojan", "Medium"),
                new Question("What does hashing provide?", new List<string>{"Encryption","Integrity","Compression","Authentication"}, "Integrity", "Medium"),
                new Question("Which protocol secures wireless networks?", new List<string>{"WEP","WPA2","FTP","HTTP"}, "WPA2", "Hard"),
                new Question("Which attack tricks users into revealing information?", new List<string>{"Spoofing","Phishing","Sniffing","Brute force"}, "Phishing", "Hard"),
                new Question("Which principle grants minimum required access?", new List<string>{"Least Privilege","Maximum Control","Full Access","Admin Override"}, "Least Privilege", "Hard")
            };
            Questions.AddRange(csQuestions);
            if (csCat != null) Quizzes.Add(new Quiz("Cybersecurity Basics Quiz", "Cybersecurity Basics questions", csCat, csQuestions, DateTime.MinValue));

            // Computer Networks
            var cnCat = Categories.Find(c => c.CategoryName == "Computer Networks");
            var cnQuestions = new List<Question>
            {
                new Question("What does IP stand for?", new List<string>{"Internet Protocol","Internal Process","Interface Program","Information Packet"}, "Internet Protocol", "Easy"),
                new Question("Which device connects networks together?", new List<string>{"Switch","Router","Hub","Repeater"}, "Router", "Easy"),
                new Question("Which protocol is used for web pages?", new List<string>{"FTP","SMTP","HTTP","TCP"}, "HTTP", "Easy"),
                new Question("Which layer handles routing?", new List<string>{"Application","Transport","Network","Data Link"}, "Network", "Medium"),
                new Question("What does DNS do?", new List<string>{"Encrypt data","Resolve domain names","Transfer files","Route packets"}, "Resolve domain names", "Medium"),
                new Question("Which protocol sends emails?", new List<string>{"HTTP","FTP","SMTP","TCP"}, "SMTP", "Medium"),
                new Question("What is a MAC address?", new List<string>{"Logical address","Physical address","IP address","Domain name"}, "Physical address", "Medium"),
                new Question("Which protocol guarantees delivery?", new List<string>{"UDP","IP","TCP","HTTP"}, "TCP", "Hard"),
                new Question("Which topology has a single central node?", new List<string>{"Ring","Mesh","Star","Bus"}, "Star", "Hard"),
                new Question("Which device operates at Layer 2?", new List<string>{"Router","Switch","Gateway","Firewall"}, "Switch", "Hard")
            };
            Questions.AddRange(cnQuestions);
            if (cnCat != null) Quizzes.Add(new Quiz("Computer Networks Quiz", "Computer Networks questions", cnCat, cnQuestions, DateTime.MinValue));
        }

        public static string AuthenticateAdmin(string username, string password)
            => Users.FirstOrDefault(x => x.Role == "Admin" && x.Username == username && x.Password == password)?.Username;

        public static string AuthenticateStudent(string username, string password)
            => Users.FirstOrDefault(x => x.Role == "Student" && x.Username == username && x.Password == password)?.Username;

        public static void AddStudent(string username, string password, string email)
        {
            Users.Add(new Student(username, password, email, "active", null));
            SaveStudentsToCsv(StudentsCsv);
        }

        public static bool RemoveStudentByUsername(string username)
        {
            var u = Users.FirstOrDefault(x => x.Role == "Student" && x.Username == username);
            if (u != null) { Users.Remove(u); SaveStudentsToCsv(StudentsCsv); return true; }
            return false;
        }

        public static List<Quiz> GetQuizzesByCategoryId(int categoryId)
            => Quizzes.Where(q => q.QuizCategory != null && q.QuizCategory.CategoryID == categoryId).ToList();

        public static void RecordStudentResult(string username, int categoryId, int score)
        {
            var existing = Results.FirstOrDefault(r => r.Username == username && r.CategoryID == categoryId);
            if (existing == null) Results.Add(new ResultRecord { Username = username, CategoryID = categoryId, Score = score });
            else if (score > existing.Score) existing.Score = score;
            SaveResultsToCsv(ResultsCsv);
        }

        public static List<Tuple<Category, int>> GetStudentResults(string username)
        {
            var list = new List<Tuple<Category, int>>();
            foreach (var r in Results.Where(x => x.Username == username))
            {
                var cat = Categories.FirstOrDefault(c => c.CategoryID == r.CategoryID);
                if (cat != null) list.Add(Tuple.Create(cat, r.Score));
            }
            return list;
        }

        public static int GetMaxPointsForCategory(int categoryId)
        {
            var quiz = Quizzes.FirstOrDefault(q => q.QuizCategory != null && q.QuizCategory.CategoryID == categoryId);
            if (quiz == null) return 0;
            int max = 0;
            foreach (var qq in quiz.QuizQuestions)
            {
                var diff = (qq.QuestionDifficultyLevel ?? "").Trim().ToLower();
                max += diff == "easy" ? 1 : diff == "medium" ? 2 : diff == "hard" ? 3 : 0;
            }
            return max;
        }

        public static void SaveQuestionsToCsv(string path)
        {
            try
            {
                using (var sw = new StreamWriter(path, false))
                {
                    sw.WriteLine("QuestionID,QuestionText,Options,CorrectAnswer,Difficulty");
                    foreach (var q in Questions)
                    {
                        var opts = string.Join("|", q.QuestionOptions ?? new List<string>());
                        sw.WriteLine($"{q.QuestionID},\"{q.QuestionText}\",\"{opts}\",\"{q.QuestionCorrectAnswer}\",{q.QuestionDifficultyLevel}");
                    }
                }
            }
            catch { }
        }

        public static void SaveStudentsToCsv(string path)
        {
            try
            {
                using (var sw = new StreamWriter(path, false))
                {
                    sw.WriteLine("Username,Password,Email,Role");
                    foreach (var u in Users.Where(x => x.Role == "Student")) sw.WriteLine($"{u.Username},{u.Password},{u.Email},Student");
                }
            }
            catch { }
        }

        // CSV result/student load/save are no-ops or simple here; adjust if you need persistence
        public static void LoadStudentsFromCsv(string path) { }
        public static void LoadResultsFromCsv(string path) { }
        public static void SaveResultsToCsv(string path) { }
    }
}