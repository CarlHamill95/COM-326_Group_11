﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Group_work_OOP
{
    public class StudentAccount
    {
        public string StudentName { get; set; }
        public string StudentPassword { get; set; }
    }

    public class AdminAccount
    {
        public string AdminName { get; set; }
        public string AdminPass { get; set; }
    }

    public static class UserAccounts
    {
        public static List<StudentAccount> studentList = new List<StudentAccount>()
        {
            new StudentAccount { StudentName = "John", StudentPassword = "1234" }
        };

        public static List<AdminAccount> adminList = new List<AdminAccount>()
        {
            new AdminAccount { AdminName = "Ronan", AdminPass = "Password" }
        };
    }
}
