﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Group_work_OOP
{
    public static class LoginMainMenu
    {
        // Removed duplicate Main method to avoid multiple entry points.

        public static void StudentLogin()
        {
            Console.WriteLine("Welcome To the Student Login\n");

            Console.Write("Username: ");
            string inputStudentUsername = Console.ReadLine();

            Console.Write("Password: ");
            string inputStudentPassword = Console.ReadLine();

            bool checkStudent = UserAccounts.studentList.Any(s =>
                s.StudentName == inputStudentUsername &&
                s.StudentPassword == inputStudentPassword);

            if (checkStudent)
            {
                Console.WriteLine("Student successful Welcome " + inputStudentUsername);
            }
            else
            {
                Console.WriteLine("Student login unsuccessful,");
            }
        }

        public static void AdminLogin()
        {
            Console.WriteLine("Welcome To the Admin Login\n");

            Console.Write("Username: ");
            string inputAdminUsername = Console.ReadLine();

            Console.Write("Password: ");
            string inputAdminPassword = Console.ReadLine();

            bool checkAdmin = UserAccounts.adminList.Any(a =>
                a.AdminName == inputAdminUsername &&
                a.AdminPass == inputAdminPassword);

            if (checkAdmin)
            {
                Console.WriteLine("Admin Login Successful, welcome " + inputAdminUsername);
            }
            else
            {
                Console.WriteLine("Admin login unsuccessful");
            }
        }
    }
}
