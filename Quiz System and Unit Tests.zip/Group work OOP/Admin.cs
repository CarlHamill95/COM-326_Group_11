using System;

namespace Group_work_OOP
{
    // Administrator user class
    public class Admin : User
    {
        private DateTime _lastLoginDate;

        // Last login date for this administrator
        public DateTime LoginDate { get { return _lastLoginDate; } set { _lastLoginDate = value; } }

        // Default administrator
        public Admin() : base()
        {
            Role = "Admin";
            _lastLoginDate = DateTime.MinValue;
        }

        // Create administrator with given values
        public Admin(string userName, string password, string email, DateTime lastLogin)
            : base(userName, password, email, "Admin")
        {
            _lastLoginDate = lastLogin;
        }
    }
}
