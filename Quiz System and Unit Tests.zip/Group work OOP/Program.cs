﻿using System;
using System.Collections.Generic;

namespace Group_work_OOP
{
    public class Program
    {
        public static void Main(string[] args)
        {
            MainController();
        }

        private static void MainController()
        {
            while (true)
            {
                try
                {
                    Console.Clear();
                    Console.WriteLine("Welcome to the Online Quiz System");
                    Console.WriteLine("1. Admin");
                    Console.WriteLine("2. Student");
                    Console.WriteLine("3. Exit");
                    Console.Write("Select an option: ");
                    string selection = Console.ReadLine();
                    if (selection != null) selection = selection.Trim();

                    if (selection == "1") AdminMenu();
                    else if (selection == "2") StudentMenu();
                    else if (selection == "3") return;
                    else
                    {
                        Console.WriteLine("Invalid option. Please press any key to continue.");
                        Console.ReadKey();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("An error occurred " + ex.Message);
                    Console.WriteLine("Please press any key to continue.");
                    Console.ReadKey();
                }
            }
        }

        private static void AdminMenu()
        {
            Console.Clear();
            var username = ReadNonEmpty("Admin Username: ");
            var password = ReadNonEmpty("Admin Password: ");

            var adminUsername = QuizSystem.AuthenticateAdmin(username, password);
            if (adminUsername == null)
            {
                Console.WriteLine("Authentication failed. Please press any key to return.");
                Console.ReadKey();
                return;
            }

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Administrator user " + adminUsername);
                Console.WriteLine("1. Manage Users");
                Console.WriteLine("2. Manage Categories");
                Console.WriteLine("3. Manage Questions");
                Console.WriteLine("4. Save all questions to CSV file");
                Console.WriteLine("5. Logout");
                Console.Write("Select an option: ");
                string selection = Console.ReadLine();
                if (selection != null) selection = selection.Trim();

                if (selection == "1") ManageUsers(adminUsername);
                else if (selection == "2") ManageCategories();
                else if (selection == "3") ManageQuestions();
                else if (selection == "4")
                {
                    try
                    {
                        QuizSystem.SaveQuestionsToCsv("questions.csv");
                        Console.WriteLine("Questions saved to questions.csv. Please press any key to continue.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Failed to save questions " + ex.Message);
                    }
                    Console.ReadKey();
                }
                else if (selection == "5") return;
                else
                {
                    Console.WriteLine("Invalid option. Please press any key to continue.");
                    Console.ReadKey();
                }
            }
        }

        private static void ManageUsers(string adminUsername)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Manage Users");
                Console.WriteLine("1. Add Student");
                Console.WriteLine("2. Remove Student");
                Console.WriteLine("3. Back to previous menu");
                Console.Write("Select an option: ");
                string selection = Console.ReadLine();
                if (selection != null) selection = selection.Trim();

                if (selection == "1")
                {
                    var newUsername = ReadNonEmpty("Username: ");
                    var newPassword = ReadNonEmpty("Password: ");
                    var newEmail = ReadNonEmpty("Email: ");
                    QuizSystem.AddStudent(newUsername, newPassword, newEmail);
                    Console.WriteLine("Student account added. Please press any key to continue.");
                    Console.ReadKey();
                }
                else if (selection == "2")
                {
                    var usernameToRemove = ReadNonEmpty("Enter student username to remove: ");
                    bool removed = QuizSystem.RemoveStudentByUsername(usernameToRemove);
                    if (removed) Console.WriteLine("Student account removed. Please press any key to continue.");
                    else Console.WriteLine("Student not found. Please press any key to continue.");
                    Console.ReadKey();
                }
                else if (selection == "3") return;
                else
                {
                    Console.WriteLine("Invalid option. Please press any key to continue.");
                    Console.ReadKey();
                }
            }
        }

        private static void ManageCategories()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Manage Categories");
                Console.WriteLine("1. Add Category");
                Console.WriteLine("2. Remove Category");
                Console.WriteLine("3. List Categories");
                Console.WriteLine("4. Back to previous menu");
                Console.Write("Select an option: ");
                string selection = Console.ReadLine();
                if (selection != null) selection = selection.Trim();

                if (selection == "1")
                {
                    var categoryName = ReadNonEmpty("Name: ");
                    var categoryDescription = ReadNonEmpty("Description: ");
                    var newCategory = new Category(categoryName, categoryDescription);
                    QuizSystem.Categories.Add(newCategory);
                    Console.WriteLine("Category added. Please press any key to continue.");
                    Console.ReadKey();
                }
                else if (selection == "2")
                {
                    int categoryIdToRemove = ReadInt("Category ID to remove: ");
                    Category foundCategory = null;
                    for (int i = 0; i < QuizSystem.Categories.Count; i++)
                    {
                        if (QuizSystem.Categories[i].CategoryID == categoryIdToRemove)
                        {
                            foundCategory = QuizSystem.Categories[i];
                            break;
                        }
                    }
                    if (foundCategory != null)
                    {
                        bool isUsed = false;
                        for (int i = 0; i < QuizSystem.Quizzes.Count; i++)
                        {
                            var quiz = QuizSystem.Quizzes[i];
                            if (quiz.QuizCategory != null && quiz.QuizCategory.CategoryID == foundCategory.CategoryID)
                            {
                                isUsed = true;
                            }
                        }
                        if (isUsed)
                        {
                            Console.WriteLine("Cannot remove category while quizzes reference it. Remove related quizzes first.");
                            Console.WriteLine("Please press any key to continue.");
                            Console.ReadKey();
                        }
                        else if (ConfirmAction("Are you sure you want to remove this category? Enter y to confirm: "))
                        {
                            QuizSystem.Categories.Remove(foundCategory);
                            Console.WriteLine("Category removed. Please press any key to continue.");
                            Console.ReadKey();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Category not found. Please press any key to continue.");
                        Console.ReadKey();
                    }
                }
                else if (selection == "3")
                {
                    Console.WriteLine("Categories:");
                    for (int i = 0; i < QuizSystem.Categories.Count; i++)
                    {
                        var currentCategory = QuizSystem.Categories[i];
                        Console.WriteLine(currentCategory.CategoryID + ": " + currentCategory.CategoryName + "  " + currentCategory.CategoryDescription);
                    }
                    Console.WriteLine("Please press any key to continue.");
                    Console.ReadKey();
                }
                else if (selection == "4") return;
                else
                {
                    Console.WriteLine("Invalid option. Please press any key to continue.");
                    Console.ReadKey();
                }
            }
        }

        private static void ManageQuestions()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Manage Questions");
                Console.WriteLine("1. Add Question");
                Console.WriteLine("2. Remove Question");
                Console.WriteLine("3. List Questions");
                Console.WriteLine("4. Back to previous menu");
                Console.Write("Select an option: ");
                string selection = Console.ReadLine();
                if (selection != null) selection = selection.Trim();

                if (selection == "1")
                {
                    var questionText = ReadNonEmpty("Question text: ");
                    var options = new List<string>();
                    for (int i = 0; i < 4; i++)
                    {
                        var optionText = ReadNonEmpty("Option " + (i + 1) + ": ");
                        options.Add(optionText);
                    }
                    string correctAnswer = "";
                    while (true)
                    {
                        correctAnswer = ReadNonEmpty("Correct answer enter the exact option text: ");
                        bool found = false;
                        for (int i = 0; i < options.Count; i++)
                        {
                            if (options[i] == correctAnswer)
                            {
                                found = true;
                                break;
                            }
                        }
                        if (found) break;
                        Console.WriteLine("Correct answer must match one of the provided options. Please try again.");
                    }
                    var difficulty = ReadNonEmpty("Difficulty (Easy/Medium/Hard): ");
                    var newQuestion = new Question(questionText, options, correctAnswer, difficulty);
                    QuizSystem.Questions.Add(newQuestion);
                    Console.WriteLine("Question added. Please press any key to continue.");
                    Console.ReadKey();
                }
                else if (selection == "2")
                {
                    int questionIdToRemove = ReadInt("Question ID to remove: ");
                    Question questionToRemove = null;
                    for (int i = 0; i < QuizSystem.Questions.Count; i++)
                    {
                        if (QuizSystem.Questions[i].QuestionID == questionIdToRemove)
                        {
                            questionToRemove = QuizSystem.Questions[i];
                            break;
                        }
                    }
                    if (questionToRemove != null)
                    {
                        if (ConfirmAction("Are you sure you want to remove this question? Enter y to confirm: "))
                        {
                            QuizSystem.Questions.Remove(questionToRemove);
                            Console.WriteLine("Question removed. Please press any key to continue.");
                        }
                        else Console.WriteLine("Removal cancelled.");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Question not found. Please press any key to continue.");
                        Console.ReadKey();
                    }
                }
                else if (selection == "3")
                {
                    Console.WriteLine("Questions:");
                    for (int i = 0; i < QuizSystem.Questions.Count; i++)
                    {
                        var currentQuestion = QuizSystem.Questions[i];
                        Console.WriteLine(currentQuestion.QuestionID + ": " + currentQuestion.QuestionText);
                    }
                    Console.WriteLine("Please press any key to continue.");
                    Console.ReadKey();
                }
                else if (selection == "4") return;
                else
                {
                    Console.WriteLine("Invalid option. Please press any key to continue.");
                    Console.ReadKey();
                }
            }
        }

        private static void StudentMenu()
        {
            Console.Clear();
            var username = ReadNonEmpty("Student Username: ");
            var password = ReadNonEmpty("Password: ");

            var studentUsername = QuizSystem.AuthenticateStudent(username, password);
            if (studentUsername == null)
            {
                Console.WriteLine("Authentication failed. Please press any key to return.");
                Console.ReadKey();
                return;
            }

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Student user " + studentUsername);
                Console.WriteLine("1. Select Category and Play Quiz");
                Console.WriteLine("2. View Results");
                Console.WriteLine("3. Logout");
                Console.Write("Select an option: ");
                string selection = Console.ReadLine();
                if (selection != null) selection = selection.Trim();

                if (selection == "1") PlayQuiz(studentUsername);
                else if (selection == "2") ViewResults(studentUsername);
                else if (selection == "3") return;
                else
                {
                    Console.WriteLine("Invalid option. Please press any key to continue.");
                    Console.ReadKey();
                }
            }
        }

        private static void PlayQuiz(string studentUsername)
        {
            Console.Clear();
            Console.WriteLine("Available Categories:");
            for (int i = 0; i < QuizSystem.Categories.Count; i++)
            {
                var currentCategory = QuizSystem.Categories[i];
                // show a simple index to pick
                Console.WriteLine((i + 1) + ": " + currentCategory.CategoryName);
            }

            int selectedIndex = ReadInt("Enter category number: ");
            if (selectedIndex < 1 || selectedIndex > QuizSystem.Categories.Count)
            {
                Console.WriteLine("Invalid category selection. Please press any key to continue.");
                Console.ReadKey();
                return;
            }

            var foundCategory = QuizSystem.Categories[selectedIndex - 1];
            int selectedCategoryId = foundCategory.CategoryID;

            var quizzesForCategory = QuizSystem.GetQuizzesByCategoryId(selectedCategoryId);
            // fallback: if no quizzes matched by CategoryID, try matching by category name (handles mismatched Category instances)
            if ((quizzesForCategory == null || quizzesForCategory.Count == 0) && foundCategory != null)
            {
                quizzesForCategory = new List<Quiz>();
                for (int qi = 0; qi < QuizSystem.Quizzes.Count; qi++)
                {
                    var q = QuizSystem.Quizzes[qi];
                    if (q.QuizCategory != null && string.Equals(q.QuizCategory.CategoryName, foundCategory.CategoryName, StringComparison.OrdinalIgnoreCase))
                    {
                        quizzesForCategory.Add(q);
                    }
                }
            }

            if (quizzesForCategory == null || quizzesForCategory.Count == 0)
            {
                Console.WriteLine("No quizzes available for this category. Please press any key to continue.");
                Console.ReadKey();
                return;
            }

            var selectedQuiz = quizzesForCategory[0]; // pick first quiz for simplicity
            int score = 0;
            int maxPoints = 0;
            for (int questionIndex = 0; questionIndex < selectedQuiz.QuizQuestions.Count; questionIndex++)
            {
                var currentQuestion = selectedQuiz.QuizQuestions[questionIndex];
                Console.Clear();
                Console.WriteLine(currentQuestion.QuestionText);
                for (int optionIndex = 0; optionIndex < currentQuestion.QuestionOptions.Count; optionIndex++)
                {
                    Console.WriteLine((optionIndex + 1) + ". " + currentQuestion.QuestionOptions[optionIndex]);
                }

                int chosenOption = -1;
                while (true)
                {
                    Console.Write("Select option number: ");
                    string raw = Console.ReadLine();
                    if (raw != null) raw = raw.Trim();
                    int parsed = 0;
                    bool ok = int.TryParse(raw, out parsed);
                    if (ok && parsed >= 1 && parsed <= currentQuestion.QuestionOptions.Count)
                    {
                        chosenOption = parsed;
                        break;
                    }
                    Console.WriteLine("Invalid selection. Please enter the option number shown.");
                }

                var selectedText = currentQuestion.QuestionOptions[chosenOption - 1];
                string selectedLower = selectedText.Trim().ToLower();
                string correctLower = currentQuestion.QuestionCorrectAnswer.Trim().ToLower();
                int questionPoints = DifficultyToPoints(currentQuestion.QuestionDifficultyLevel);
                if (selectedLower == correctLower) score += questionPoints;
                maxPoints += questionPoints;
            }

            // Record best score by category
            QuizSystem.RecordStudentResult(studentUsername, selectedCategoryId, score);

            double percent = maxPoints == 0 ? 0.0 : (100.0 * score) / maxPoints;
            Console.WriteLine("Quiz complete. Score " + score + "/" + maxPoints + " (" + Math.Round(percent, 1) + "%)");
            Console.WriteLine("Please press any key to continue.");
            Console.ReadKey();
        }

        private static void ViewResults(string studentUsername)
        {
            Console.Clear();
            Console.WriteLine("Your Results:");
            var results = QuizSystem.GetStudentResults(studentUsername);
            if (results == null || results.Count == 0)
            {
                Console.WriteLine("No results found. Please press any key to continue.");
                Console.ReadKey();
                return;
            }

            foreach (var r in results)
            {
                var category = r.Item1;
                int bestScore = r.Item2;
                int max = QuizSystem.GetMaxPointsForCategory(category.CategoryID);
                double percent = max == 0 ? 0.0 : ((double)bestScore / (double)max) * 100.0;
                Console.WriteLine(category.CategoryName + ": " + bestScore + "/" + max + " (" + Math.Round(percent, 1) + "%)");
            }

            Console.WriteLine("Please press any key to continue.");
            Console.ReadKey();
        }

        private static int DifficultyToPoints(string difficulty)
        {
            if (difficulty == null) return 0;
            difficulty = difficulty.Trim().ToLower();
            if (difficulty == "easy") return 1;
            if (difficulty == "medium") return 2;
            if (difficulty == "hard") return 3;
            return 0;
        }

        private static string ReadNonEmpty(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = Console.ReadLine();
                if (s != null) s = s.Trim();
                if (!string.IsNullOrEmpty(s)) return s;
                Console.WriteLine("Input cannot be empty. Please try again.");
            }
        }

        private static int ReadInt(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string raw = Console.ReadLine();
                if (raw != null) raw = raw.Trim();
                int val = 0;
                bool ok = int.TryParse(raw, out val);
                if (ok) return val;
                Console.WriteLine("Please enter a valid number.");
            }
        }

        private static bool ConfirmAction(string prompt)
        {
            Console.Write(prompt);
            string resp = Console.ReadLine();
            if (resp != null) resp = resp.Trim().ToLower();
            if (resp == "y" || resp == "yes") return true;
            return false;
        }
    }
}
