﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Group_work_OOP;

namespace QuizSystemTests
{
    [TestClass]
    public class QuizSystemTests
    {
        // Test Case: Verify Admin authentication logic.
        // Expected Output: Returns the username string when credentials match an Admin.
        [TestMethod]
        public void AuthenticateAdmin_ShouldReturnUsername_WhenCredentialsCorrect()
        {
            // Arrange & Act: Authenticate with the Admin that actually exists (Ronan)
            // Note: Ensure the casing matches exactly what is in Accounts.cs
            string result = QuizSystem.AuthenticateAdmin("Ronan", "Password");

            // Assert: Result should match the username "Ronan"
            Assert.AreEqual("Ronan", result);
        }

        // Test Case: Verify authentication failure handling.
        // Expected Output: Returns null when the password is incorrect.
        [TestMethod]
        public void AuthenticateStudent_ShouldReturnNull_WhenPasswordWrong()
        {
            // Arrange & Act: Attempt to authenticate with a wrong password
            string result = QuizSystem.AuthenticateStudent("john", "WRONGPASSWORD");

            // Assert: Result should be null indicating failure
            Assert.IsNull(result);
        }

        // Test Case: Verify that adding a student increases the user list and allows login.
        // Expected Output: The new user can be authenticated immediately after addition.
        [TestMethod]
        public void AddStudent_ShouldIncreaseUserCount()
        {
            // Arrange: Generate a unique username to avoid conflicts with other tests
            string newUser = "UniqueTestStudent_" + System.Guid.NewGuid();

            // Act: Add the student and then try to authenticate as them
            QuizSystem.AddStudent(newUser, "pass", "email@test.com");
            string authResult = QuizSystem.AuthenticateStudent(newUser, "pass");

            // Assert: Authentication should succeed (return the username)
            Assert.AreEqual(newUser, authResult);
        }

        // Test Case: Verify removal of student accounts.
        // Expected Output: RemoveStudentByUsername returns true, and subsequent login fails (null).
        [TestMethod]
        public void RemoveStudent_ShouldRemoveUser()
        {
            // Arrange: Add a temporary user to be removed
            string userToRemove = "RemoveMe_" + System.Guid.NewGuid();
            QuizSystem.AddStudent(userToRemove, "pass", "email");

            // Act: Remove the user and attempt to authenticate again
            bool removed = QuizSystem.RemoveStudentByUsername(userToRemove);
            string authResult = QuizSystem.AuthenticateStudent(userToRemove, "pass");

            // Assert: Removal returned true, and authentication returns null
            Assert.IsTrue(removed);
            Assert.IsNull(authResult);
        }
    }
}