﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Group_work_OOP;
using System;

namespace QuizSystemTests
{
    [TestClass]
    public class AdminTests
    {
        // Test Case: Verify the Admin constructor correctly stores the login date.
        // Expected Output: The LoginDate property matches the DateTime passed to the constructor.
        [TestMethod]
        public void Admin_Constructor_ShouldSetLoginDate()
        {
            // Arrange: Capture the current time
            DateTime loginTime = DateTime.Now;

            // Act: Create an Admin with that login time
            Admin a = new Admin("admin1", "pass", "a@ulster.ac.uk", loginTime);

            // Assert: Verify the Role is "Admin" and LoginDate is stored correctly
            Assert.AreEqual("Admin", a.Role);
            Assert.AreEqual(loginTime, a.LoginDate);
        }
    }
}