﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Group_work_OOP;
using System.Collections.Generic;

namespace QuizSystemTests
{
    [TestClass]
    public class QuestionTests
    {
        // Test Case: Verify that Question options are stored as a list.
        // Expected Output: The QuestionOptions list count matches the input list count.
        [TestMethod]
        public void Question_ShouldStoreOptionsList()
        {
            // Arrange: Create a list of options strings
            string text = "What is 2+2?";
            List<string> options = new List<string> { "3", "4", "5" };
            string correct = "4";
            string diff = "Easy";

            // Act: Create the Question object
            Question q = new Question(text, options, correct, diff);

            // Assert: Verify text, options count, and correct answer
            Assert.AreEqual(text, q.QuestionText);
            Assert.AreEqual(3, q.QuestionOptions.Count);
            Assert.AreEqual("4", q.QuestionCorrectAnswer);
        }
    }
}