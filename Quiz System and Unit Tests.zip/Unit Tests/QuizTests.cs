﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Group_work_OOP;
using System;
using System.Collections.Generic;

namespace QuizSystemTests
{
    [TestClass]
    public class QuizTests
    {
        // Test Case: Verify Quiz composition (contains Category and Questions).
        // Expected Output: QuizCategory is not null, and QuizQuestions count is correct.
        [TestMethod]
        public void Quiz_ShouldContainQuestionsAndCategory()
        {
            // Arrange: Create dependencies (Category and a Question list)
            Category cat = new Category("Test Cat", "Desc");
            Question q1 = new Question();
            List<Question> questions = new List<Question> { q1 };
            DateTime date = DateTime.Today;

            // Act: Create the Quiz object injecting these dependencies
            Quiz quiz = new Quiz("My Quiz", "Description", cat, questions, date);

            // Assert: Verify the object references and list contents are correct
            Assert.AreEqual("My Quiz", quiz.QuizTitle);
            Assert.AreEqual(cat, quiz.QuizCategory);
            Assert.AreEqual(1, quiz.QuizQuestions.Count);
            Assert.AreEqual(date, quiz.QuizDate);
        }
    }
}