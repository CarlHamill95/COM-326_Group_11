﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Group_work_OOP;

namespace QuizSystemTests
{
    [TestClass]
    public class CategoryTests
    {
        // Test Case: Verify Category data integrity.
        // Expected Output: Name and Description match inputs; ID is greater than 0 (auto-generated).
        [TestMethod]
        public void Category_ShouldStoreDataCorrectly()
        {
            // Arrange: Define category details
            string name = "OOP";
            string desc = "Object Oriented Programming";

            // Act: Instantiate the Category
            Category c = new Category(name, desc);

            // Assert: Check properties and ensure ID was auto-incremented
            Assert.AreEqual(name, c.CategoryName);
            Assert.AreEqual(desc, c.CategoryDescription);
            Assert.IsTrue(c.CategoryID > 0);
        }
    }
}