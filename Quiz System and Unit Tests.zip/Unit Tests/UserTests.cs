﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Group_work_OOP;

namespace QuizSystemTests
{
    [TestClass]
    public class UserTests
    {
        // Test Case: Verify that the default constructor sets valid default values.
        // Expected Output: ID is not null, Role is "User", and Username is empty.
        [TestMethod]
        public void User_DefaultConstructor_ShouldSetDefaults()
        {
            // Arrange: Create a new User object using the default constructor
            User u = new User();

            // Act: (No action needed as we are testing the state immediately after creation)

            // Assert: Verify the default properties are set correctly
            Assert.IsNotNull(u.Id);
            Assert.AreEqual("User", u.Role);
            Assert.AreEqual(string.Empty, u.Username);
        }

        // Test Case: Verify that the parameterized constructor correctly sets properties.
        // Expected Output: Username, Password, Email, and Role match the input arguments.
        [TestMethod]
        public void User_ParameterizedConstructor_ShouldSetProperties()
        {
            // Arrange: Define the input values for the user
            string name = "testUser";
            string pass = "testPass";
            string email = "test@email.com";
            string role = "Tester";

            // Act: Create the user with the specific values
            User u = new User(name, pass, email, role);

            // Assert: Verify that the object properties match the inputs
            Assert.AreEqual(name, u.Username);
            Assert.AreEqual(pass, u.Password);
            Assert.AreEqual(email, u.Email);
            Assert.AreEqual(role, u.Role);
        }
    }
}