﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Group_work_OOP;
using System;

namespace QuizSystemTests
{
    [TestClass]
    public class StudentTests
    {
        // Test Case: Verify Student inheritance and specific role assignment.
        // Expected Output: Role is "Student" (inherited from User), and Status is "active".
        [TestMethod]
        public void Student_Constructor_ShouldSetStudentRole()
        {
            // Arrange: Create a new Student with specific credentials
            Student s = new Student("student1", "pass", "s@ulster.ac.uk", "active", null);

            // Act: (State verification only)

            // Assert: Check inherited Role and specific Status property
            Assert.AreEqual("Student", s.Role);
            Assert.AreEqual("student1", s.Username);
            Assert.AreEqual("active", s.Status);
        }

        // Test Case: Verify that the status can be changed when a valid Admin is provided.
        // Expected Output: The Student status changes from "active" to "inactive".
        [TestMethod]
        public void SetStatus_ShouldUpdateStatus_WhenAdminProvided()
        {
            // Arrange: Create a student and an admin helper
            Student s = new Student();
            Admin admin = new Admin();
            string newStatus = "inactive";

            // Act: Call SetStatus passing the admin object
            s.SetStatus(newStatus, admin);

            // Assert: Verify the status was actually updated
            Assert.AreEqual(newStatus, s.Status);
        }

        // Test Case: Verify that SetStatus throws an error if the Admin argument is null.
        // Expected Output: An ArgumentNullException is thrown.
        [TestMethod]
        public void SetStatus_ShouldThrowException_WhenAdminIsNull()
        {
            // Arrange: Create a student object
            Student s = new Student();

            // Act & Assert: Execute the method in a try-catch to verify the exception
            try
            {
                s.SetStatus("inactive", null); // This should fail
                Assert.Fail("An ArgumentNullException should have been thrown, but it wasn't.");
            }
            catch (ArgumentNullException)
            {
                // Success: The correct exception was caught
            }
            catch (Exception ex)
            {
                // Fail: The wrong type of exception occurred
                Assert.Fail("Expected ArgumentNullException, but got " + ex.GetType().Name);
            }
        }
    }
}