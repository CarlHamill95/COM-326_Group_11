﻿class Program
{
    static void Main(string[] args)
    {
        bool showMenu = true;
        while (showMenu)
        {
            showMenu = CategoryMenu();
        }
    }
    private static int CategoryMenu()
    {
        Console.Clear();
        Console.WriteLine("Please Choose a quiz you would like to complete:");
        Console.WriteLine("(1) Programming");
        Console.WriteLine("(2) Data Structures");
        Console.WriteLine("(3) Software Design");
        Console.WriteLine("(4) Web Development");
        Console.WriteLine("(5) Database Systens");
        Console.WriteLine("(6) Cybersecurity Basics");
        Console.WriteLine("(7) Computer Networks");
        Console.WriteLine("(8) Exit");
        Console.Write("\r\nSelect an option: ");

        switch (Console.ReadLine())
        {
            case "1":
                ProgrammingQuiz();
                return true;
            case "2":
                dataStructureQuiz();
                return true;
            case "3":
                softwareDesignQuiz();
                return false;
            case "4":
                webDevelopmentQuiz();
                return true;
            case "5":
                databaseQuiz();
                return true;
            case "6":
                cybersecurityQuiz();
                return true;
            case "7":
                networkQuiz();
                return true;
            case "8":
                Back();
            return true;
                    
            default:
                Console.WriteLine("Invalid option selected");
                break;
        }
    }

    private static string ProgrammingQuiz()
    {
        Console.WriteLine("Enter the string you want to modify: ");
        return CategoryMenu();
    
    }
    private static string dataStructureQuiz()
    {
        Console.WriteLine("Enter the string you want to modify: ");
        return MainMenu;

    }
    private static string softwareDesignQuiz()
    {
        Console.WriteLine("Enter the string you want to modify: ");
        return MainMenu;

    }
    private static string webDevelopmentQuiz()
    {
        Console.WriteLine("Enter the string you want to modify: ");
        return MainMenu;

    }
    private static string databaseQuiz()
    {
        Console.WriteLine("Enter the string you want to modify: ");
        return MainMenu;

    }
    private static string cybersecurityQuiz()
    {
        Console.WriteLine("Enter the string you want to modify: ");
        return MainMenu;

    }
    private static string networkQuiz()
    {
        Console.WriteLine("Enter the string you want to modify: ");
        return MainMenu;

    }
    private static string Back()
    {
        Console.WriteLine("Enter the string you want to modify: ");
        

    }


}


